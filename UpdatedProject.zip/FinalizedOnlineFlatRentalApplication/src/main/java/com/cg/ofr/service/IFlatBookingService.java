package com.cg.ofr.service;

import java.util.List;


import com.cg.ofr.entities.FlatBooking;
import com.cg.ofr.exception.EntityNotFoundException;

public interface IFlatBookingService {
	
	public FlatBooking addFlatBooking(FlatBooking flatbooking);

	public FlatBooking updateFlatBooking(FlatBooking flatbooking);

	public FlatBooking deleteFlatBooking(FlatBooking flatbooking);

	public FlatBooking viewFlatBooking(Integer id) throws EntityNotFoundException  ;

	public List<FlatBooking> viewAllFlatBooking();


}
