package com.cg.ofr.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.ofr.entities.Payment;
import com.cg.ofr.exception.EntityNotFoundException;

@Service
public interface IPaymentService {
	
	public Payment addPayment(Payment payment);

	public Payment getPaymentDetails(int id) throws EntityNotFoundException;

	public Payment deletePayment(Payment payment);

	public List<Payment> getAllPaymentDetails();

	public Payment updatePayment(Payment payment);
}