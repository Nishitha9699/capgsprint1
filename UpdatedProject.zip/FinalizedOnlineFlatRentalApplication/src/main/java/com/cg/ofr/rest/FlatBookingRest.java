package com.cg.ofr.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ofr.entities.FlatBooking;
import com.cg.ofr.exception.EntityNotFoundException;
import com.cg.ofr.service.IFlatBookingService;

import io.swagger.annotations.Api;

@RestController
@Api(value = "Swagger2DemoRestController")

public class FlatBookingRest {
	@Autowired
	private IFlatBookingService flatBookingService;

	@PostMapping("/flatbooking")
	public FlatBooking addFlatBooking(@RequestBody FlatBooking flatBooking) {
		FlatBooking flatBooking1 = null;
		flatBooking1 = flatBookingService.addFlatBooking(flatBooking);
		return flatBooking1;
	}

	@PutMapping("/flatbooking")
	public FlatBooking updateFlatBooking(@RequestBody FlatBooking flatBooking) {
		FlatBooking flatBooking2 = null;
		flatBooking2 = flatBookingService.updateFlatBooking(flatBooking);
		return flatBooking2;
	}

	@DeleteMapping("/flatbooking")
	public FlatBooking deleteFlatBooking(@RequestBody FlatBooking flatBooking) {
		FlatBooking flatBooking3 = null;
		flatBooking3 = flatBookingService.deleteFlatBooking(flatBooking);
		return flatBooking3;
	}

	@GetMapping("/flatbooking/{id}")
	public FlatBooking viewFlatBooking(@PathVariable Integer id) throws EntityNotFoundException {
		FlatBooking flatBooking4 = flatBookingService.viewFlatBooking(id);
		return flatBooking4;
	}

	@GetMapping("/flatbookings")

	public List<FlatBooking> viewAllFlatBooking() {
		List<FlatBooking> flatBookings = flatBookingService.viewAllFlatBooking();
		return flatBookings;
	}

}