package com.cg.ofr.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ofr.entities.User;
import com.cg.ofr.exception.EmptyEntityListException;
import com.cg.ofr.exception.EntityCreationException;
import com.cg.ofr.exception.EntityDeletionException;
import com.cg.ofr.exception.EntityNotFoundException;
import com.cg.ofr.exception.EntityUpdationException;
import com.cg.ofr.repository.IUserRepository;


@Service
@Transactional
public class UserServiceImpl implements IUserService {

	@Autowired
	private IUserRepository userRepository;

	
	@Override
	public User viewUser(int id) throws EntityNotFoundException {
		try {
			Optional<User> user = userRepository.findById(id);
			if (user.isPresent()) {
				return user.get();
			} else {
				throw new EntityNotFoundException("User is not found for Id " + id);
			}

		} catch (Exception e) {
			throw new EntityNotFoundException(e.getMessage());

		}

	}

	
	@Override
	public List<User> viewAllUser() {
		try {
			List<User> userList = userRepository.findAll();
			if (userList.isEmpty()) {
				throw new EmptyEntityListException(" No Users found");
			} else {
				return userList;
			}
		} catch (Exception e) {
			throw new EmptyEntityListException(e.getMessage());
		}

	}

	
	@Override
	public User validateUser(String username, String password) throws EntityNotFoundException {
		try {
			Optional<User> user = userRepository.findByuserName(username);
			if (user.isPresent()) {
				if (username.equals(user.get().getUserName()) && (password.equals(user.get().getPassword()))) {
					return user.get();
				} else {
					throw new EntityNotFoundException("Password does not match for " + username);
				}
			} else {
				throw new EntityNotFoundException("User is not there with username :" + username);
			}
		} catch (Exception e) {
			throw new EntityNotFoundException(e.getMessage());
		}
	}

	
	@Override
	public User addUser(User user) {
		try {
			return userRepository.save(user);
		} catch (Exception e) {
			throw new EntityCreationException("Valid details of user are not entered");
		}
	}

	
	@Override
	public User updateUser(User user) {
		try {
			Optional<User> user1 = userRepository.findById(user.getUserId());
			if (user1.isPresent()) {
				return userRepository.save(user);
			} else {
				return null;
			}
		} catch (Exception e) {
			throw new EntityUpdationException("No updation found");
		}

	}

	
	@Override
	public User updatePassword(User user, String newpass) throws EntityNotFoundException {
		try {
			Optional<User> checkuser = userRepository.findByuserName(user.getUserName());
			Optional<User> checkuser1 = Optional
					.of(validateUser(checkuser.get().getUserName(), checkuser.get().getPassword()));
			if (checkuser1.isPresent()) {
				user.setPassword(newpass);
				userRepository.save(user);
				return user;
			} else {
				throw new EntityNotFoundException("No user found");
			}

		} catch (Exception e) {
			throw new EntityNotFoundException(e.getMessage());
		}
	}

	
	@Override
	public User removeUser(User user) {
		try {
			Optional<User> deletedUser = userRepository.findById(user.getUserId());
			if (deletedUser.isPresent()) {
				userRepository.delete(user);
			}
			return deletedUser.get();
		} catch (Exception e) {
			throw new EntityDeletionException("Invalid user details");
		}

	}

}