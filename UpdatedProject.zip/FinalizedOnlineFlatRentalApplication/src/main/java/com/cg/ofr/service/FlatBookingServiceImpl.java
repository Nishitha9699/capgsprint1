/**
 * 
 */
package com.cg.ofr.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityNotFoundException;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ofr.entities.FlatBooking;
import com.cg.ofr.exception.EmptyEntityListException;
import com.cg.ofr.exception.EntityCreationException;
import com.cg.ofr.exception.EntityDeletionException;
import com.cg.ofr.exception.EntityUpdationException;
import com.cg.ofr.repository.IFlatBookingRepository;

@Service
@Transactional
public class FlatBookingServiceImpl implements IFlatBookingService {

	@Autowired
	private IFlatBookingRepository flatBookingRepository;

	@Override
	public FlatBooking addFlatBooking(FlatBooking flatbooking) {
		try {
			if (!flatBookingRepository.existsById(flatbooking.getBookingNo())) {
				return flatBookingRepository.save(flatbooking);
			} else {
				throw new EntityCreationException("Flatbooking Already Exists");
			}
		} catch (Exception e) {
			throw new EntityCreationException(e.getMessage());
		}
	}

	@Override
	public FlatBooking updateFlatBooking(FlatBooking flatbooking) {
		try {
			Optional<FlatBooking> flatBooking1 = flatBookingRepository.findById(flatbooking.getBookingNo());
			if (flatBooking1.isPresent()) {
				FlatBooking flatbooking2 = flatBookingRepository.save(flatbooking);
				return flatbooking2;
			} else {
				throw new EntityUpdationException(
						"Cannot Update FlatBooking with bookingNo" + flatbooking.getBookingNo());
			}
		} catch (Exception e) {
			throw new EntityUpdationException(e.getMessage());
		}
	}

	@Override
	public FlatBooking deleteFlatBooking(FlatBooking flatbooking) {
		try {
			Optional<FlatBooking> flatBooking3 = flatBookingRepository.findById(flatbooking.getBookingNo());
			if (flatBooking3.isPresent()) {
				flatBookingRepository.delete(flatbooking);
				return flatBooking3.get();
			} else {
				throw new EntityDeletionException("Cannot Delete flatbooking as the FlatBooking with"
						+ flatbooking.getBookingNo() + "does not exist");
			}
		} catch (Exception e) {
			throw new EntityDeletionException(e.getMessage());

		}

	}

	@Override
	public FlatBooking viewFlatBooking(Integer id) throws EntityNotFoundException {
		try {
			Optional<FlatBooking> flatBooking = flatBookingRepository.findById(id);
			if (flatBooking.isPresent()) {
				return flatBooking.get();
			} else {
				throw new EntityNotFoundException("the FlatBooking with id " + id + " is not found");
			}
		} catch (Exception e) {
			throw new EntityNotFoundException(e.getMessage());
		}
	}

	@Override
	public List<FlatBooking> viewAllFlatBooking() {
		List<FlatBooking> flatbookings = new ArrayList<>();
		try {
			flatbookings = flatBookingRepository.findAll();
			if (flatbookings.isEmpty()) {
				throw new EmptyEntityListException("No FlatBooking Found");
			} else
				return flatbookings;
		} catch (Exception e) {
			throw new EmptyEntityListException(e.getMessage());
		}

	}

}