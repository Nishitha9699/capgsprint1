
package com.cg.ofr;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.ofr.entities.Flat;
import com.cg.ofr.entities.FlatAddress;
import com.cg.ofr.entities.FlatBooking;
import com.cg.ofr.entities.Tenant;
import com.cg.ofr.exception.EntityNotFoundException;
import com.cg.ofr.service.IFlatBookingService;

@SpringBootTest
public class FlatBookingTests extends OnlineFlatRentalApplicationTests {

	@Autowired
	private IFlatBookingService flatBookingService;

	@Test
	public void addFlatBookingTest()  {

		FlatAddress flatAddress1 = new FlatAddress(200, "5", "Vizag", "Andhra Pradesh", 530012, "India");
		Flat flat1 = new Flat(1007, 1000000, flatAddress1, "yes");
		Tenant tenant1 = new Tenant(1, 40, null);
		FlatBooking flatBooking1 = new FlatBooking(148, LocalDate.of(2000, 01, 21), LocalDate.of(2005, 11, 26), flat1,
				tenant1);
		tenant1.setFlatbooking(flatBooking1);
		assertNotNull(flatBooking1.getBookingNo());
		assertEquals(flatBooking1.getBookingFromDate(), LocalDate.of(2000,01,21));
		System.out.println(flatBookingService.viewAllFlatBooking().size());

	}



	@Test
	public void updateFlatBookingTest() {
		FlatAddress flatAddress3 = new FlatAddress(108, "8", "Vizag", "AndhraPradesh", 530018, "India");
		Flat flat3 = new Flat(1005, 1200000, flatAddress3, "yes");
		Tenant tenant3 = new Tenant(3, 30, null);
		FlatBooking flatBooking3 = new FlatBooking(153, LocalDate.of(2020, 11, 21), LocalDate.of(2025, 06, 26), flat3,
				tenant3);
		tenant3.setFlatbooking(flatBooking3);
		FlatBooking newFlatBooking = flatBooking3;
		newFlatBooking.setBookingToDate(LocalDate.of(2020, 5, 9));
		FlatBooking flatBookingTest = flatBookingService.updateFlatBooking(flatBooking3);
		assertEquals(newFlatBooking.getBookingToDate(), flatBookingTest.getBookingToDate());

	}

	@Test
	public void deleteFlatBookingTest() {
		FlatAddress flatAddress4 = new FlatAddress(102, "2", "Vizag", "AndhraPradesh", 530012, "India");
		Flat flat4 = new Flat(1008, 200000, flatAddress4, "yes");
		Tenant tenant4 = new Tenant(5, 20, null);
		FlatBooking flatBooking4 = new FlatBooking(154, LocalDate.of(1996, 12, 21), LocalDate.of(2005, 11, 18), flat4,
				tenant4);
		tenant4.setFlatbooking(flatBooking4);
		FlatBooking NewFlatBooking = flatBookingService.deleteFlatBooking(flatBooking4);
		assertEquals(flatBooking4.getBookingNo(), NewFlatBooking.getBookingNo());

	}

	@SuppressWarnings("unused")
	@Test
	public void viewAllFlatBookingTest() {
		FlatAddress flatAddress5 = new FlatAddress(104, "6", "Vizag", "AndhraPradesh", 530092, "India");
		Flat flat5 = new Flat(1005, 100000, flatAddress5, "yes");
		Tenant tenant5 = new Tenant(5, 20, null);
		FlatBooking flatBooking5 = new FlatBooking(153, LocalDate.of(2012, 11, 26), LocalDate.of(2020, 11, 26), flat5,
				tenant5);
		tenant5.setFlatbooking(flatBooking5);
		FlatAddress flatAddress6 = new FlatAddress(105, "9", "Vizag", "AndhraPradesh", 530092, "India");
		Flat flat6 = new Flat(1006, 100000, flatAddress6, "yes");
		Tenant tenant6 = new Tenant(6, 20, null);
		FlatBooking flatBooking6 = new FlatBooking(156, LocalDate.of(2012, 06, 26), LocalDate.of(2020, 01, 29), flat6,
				tenant6);
		tenant6.setFlatbooking(flatBooking6);
		List<FlatBooking> list = flatBookingService.viewAllFlatBooking();
		assertNotNull(flatBooking5.getBookingNo());
	}

	@Test
	public void viewFlatBookingTest() throws EntityNotFoundException {
		FlatAddress flatAddress2 = new FlatAddress(101, "9", "Vizag", "AndhraPradesh", 530092, "India");
		Flat flat2 = new Flat(1002, 100000, flatAddress2, "no");
		Tenant tenant2 = new Tenant(2, 20, null);
		FlatBooking flatBooking2 = new FlatBooking(152, LocalDate.of(2020, 01, 29), LocalDate.of(2025, 06, 26), flat2,
				tenant2);
		tenant2.setFlatbooking(flatBooking2);
		FlatBooking testFlatBooking = flatBookingService.viewFlatBooking(flatBooking2.getBookingNo());
		assertEquals(flatBooking2.getBookingNo(), testFlatBooking.getBookingNo());

	}

}
